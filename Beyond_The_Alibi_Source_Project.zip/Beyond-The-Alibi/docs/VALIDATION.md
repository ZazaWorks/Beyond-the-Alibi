# Validation record — 27 October 2026

## Verified

Built with OpenJDK 17.0.20, Maven 3.9.9 and Spring Boot 3.4.13 in a Linux environment.

`mvn clean package`: **BUILD SUCCESS**.

**15 automated JUnit/Spring tests passed, zero failures or errors:**
- 11 domain and persistence tests: a name alone is insufficient; supported solution and extra links; wrong suspect; wrong relationship; discovery/deduplication; invalid IDs and witness accusation; edit/remove; complete save restoration; corrupt-save preservation; failed-save rollback; hint limits and note bounds.
- 4 API tests: hidden answer key and undiscovered clue details; mutation header and request validation; complete solve flow; static assets and response security headers.

**10 checks passed against the compiled JAR running as an actual HTTP server:**
1. Game page is served.
2. Public case contains the expected world but not the answer key.
3. All eight generated image assets are served.
4. Invalid and unmarked mutations are rejected.
5. All nine clues can be collected through HTTP.
6. A correct name alone is incomplete.
7. A wrong suspect is unsupported.
8. The supported solution is accepted.
9. Evidence, links, Unicode notes and solved state survive stopping and restarting the Java process.
10. Replay clears the saved investigation.

Frontend JavaScript syntax and POSIX launcher shell syntax were checked. All generated images were inspected at creation. The archive contains no player save data or local build credentials.

## Verification limits

The managed browser-preview environment could not execute its Java runtime, so browser interaction, responsive rendering and accessibility behavior were **not end-to-end browser-tested here**. HTML/CSS/JavaScript implement those interactions, but a visual check in Chrome/Firefox/Safari on the presentation laptop remains advisable. Windows and macOS launch scripts were provided but were not executed on those operating systems. The JAR itself was launched and tested on Linux.

## Reproduce

- `mvn test` runs the 15 automated tests with temporary save directories.
- `python scripts/smoke_test.py` runs the real-JAR checks (optional Python 3 requirement only for this test).
- `java -jar beyond-the-alibi.jar` launches the game for a manual playthrough at http://localhost:8080 .
