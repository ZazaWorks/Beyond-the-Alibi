# Architecture and OOP mapping

The browser uses same-origin REST requests. GameController receives requests; InvestigationService copies the current state, applies a domain operation, persists the new snapshot, then replaces the live state. A failed save leaves the previous live state intact. Jackson reads authored case JSON and persists versioned Progress records. No ORM or external database is necessary for the local single-player scope.

## Java concepts

| Concept | Implemented example |
|---|---|
| Classes and objects | Case, Location, Investigation, ClueLink; C01 and its concrete clues |
| Constructors | CaseLoader instantiates each evidence subtype and person |
| Encapsulation | Private state; read-only collection accessors; validated mutation methods |
| Inheritance | Suspect/Witness extend Person; three evidence types extend Evidence |
| Polymorphism | getAccount() and getSummary() return subtype-specific data |
| Abstraction | Abstract Person and Evidence contracts |
| Interfaces | VerdictEvaluator and Repository<T> |
| Exceptions | Domain validation becomes HTTP 400; save failures become HTTP 503 |
| Collections | Set of discovered IDs, List of links, Map of evidence |
| File handling | Jackson plus Files, temporary writes and atomic replacement where supported |
| Packages | model, service, repository, web |
| Generics | Repository<Progress>, List<Evidence>, Map<String,Evidence> |
| Enums | RelationType limits supported relationships |

Implementation refinement from the design report: the repository stores the versioned **Progress DTO**, rather than serializing the complete Investigation object graph. The service rebuilds a validated Investigation from the DTO. API validation uses IllegalArgumentException and a centralized handler; dedicated InvalidEvidenceException classes were unnecessary for this bounded release.

## REST endpoints

All mutations require `X-Game-Request: 1` and, when a body is present, `Content-Type: application/json`. The frontend supplies both. No CORS origins are enabled.

| Method | Path | Purpose / request |
|---|---|---|
| GET | /api/case | Public world, people and clue metadata; no solution/transcripts |
| GET | /api/state | Committed progress and discovered clue details |
| POST | /api/inspect/{id} | Inspect and collect a clue; repeated collection is idempotent |
| POST | /api/links | Add `{evidenceId, personId, relation, note}` |
| PUT | /api/links/{key} | Edit a link with the same body |
| DELETE | /api/links/{key} | Remove a canonical link key |
| PUT | /api/notes | Save `{text}` (maximum 10,000 characters) |
| PUT | /api/suspect | Set `{personId}`; witness IDs rejected |
| POST | /api/verdict | Check selected suspect and saved links |
| POST | /api/hint | Reveal the next of three hint levels |
| POST | /api/reset | Deliberately replace current progress with a fresh investigation |

A link key is `evidenceId:personId:RELATION`. URL-encode it when used in a path. Link notes are at most 500 characters; duplicate triples are rejected. A board holds up to 100 links.

## Evaluation

RuleBasedEvaluator compares the selected suspect and the required canonical link set. Fewer than three links yields incomplete; missing required links or a wrong suspect yields unsupported; a correct suspect with the required links yields solved. Extra exploratory links do not invalidate the required solution. The evaluator does not interpret free text. After solving, progress is locked until reset; the case and collected evidence remain reviewable.

## Persistence and recovery

All mutating service methods synchronize access within one JVM. Copy → validate → write temporary JSON → replace progress.json → commit in-memory state. The repository uses atomic file replacement where supported and replacement fallback otherwise. There is no claim of multi-process locking or crash-proof database durability. Use one server instance per save directory. Corrupt saves are preserved under a timestamped filename; load warns and starts a fresh investigation.

## Extending the project

Edit `src/main/resources/case/case.json` to change the story. Use unique IDs; keep referenced location/person IDs valid. Edit `solution.json` to match the required links and explanation. Rebuild and test. This version loads C01, so a case-selection UI, generalized multi-case repository keys and migration rules would be needed for a case library. Public accounts and deployment would require per-user state and authentication; do not expose this one-save local server unchanged.
