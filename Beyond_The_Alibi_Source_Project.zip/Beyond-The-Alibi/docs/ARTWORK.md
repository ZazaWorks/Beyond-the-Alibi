# Artwork and provenance

Eight original assets were created with the built-in image generation tool for this project. No external character photos are used. The people are fictional. The generated PNGs were converted to WebP for the runnable package; no external image service is contacted during play.

Final project paths: `src/main/resources/static/assets/aarav.webp`, `meera.webp`, `kabir.webp`, `isha.webp`, `lab.webp`, `library.webp`, `corridor.webp`, `tag.webp`.

## Final prompt set

Shared portrait direction: “Use case: illustration-story. Asset: individual character portrait for a fictional campus detective web game Beyond the Alibi. Chest-up portrait centered, facing slightly toward camera, head fully within frame with generous margins. Painterly editorial gouache and fine pencil illustration, warm vintage detective dossier style, muted sepia paper backdrop, dark olive and soft amber palette, beautiful restrained realistic brushwork. One person only, no text, no lettering, no border, no props, no watermark. All characters should look equally credible; no sinister visual cues. Square composition.”

- Aarav: fictional Indian male university robotics student age 21, short wavy black hair, subtle stubble, cream collared shirt under olive overshirt, neutral thoughtful expression.
- Meera: fictional Indian female university robotics student age 21, dark hair in loose low bun, round thin spectacles, burgundy knit cardigan over cream shirt, neutral observant expression.
- Kabir: fictional Indian male university robotics student age 22, thick short curly hair, clean shaven, navy work jacket over pale t-shirt, calm neutral expression.
- Isha: fictional Indian female university lab assistant age 25, shoulder length dark hair, tan lab coat over teal shirt, attentive neutral expression.

Lab: “Use case: illustration-story. Wide cinematic environment illustration for Beyond the Alibi, a fictional campus detective game. An empty university robotics laboratory at dusk, vintage warm editorial gouache and pencil style, deep olive shadows, amber desk lamp, russet and cream, fine paper grain. Long wooden workbench with an empty rectangular patch where a small robot prototype has gone missing, small electronics, steel storage cabinets, window in background with blue evening sky, corkboard with blank notes. Foreground leather notebook and desk lamp, middle bench, door on far right. Believable contemporary campus lab reinterpreted as vintage mystery art. No people, no letters, no readable text, no logos, no UI. Rich detailed painted atmosphere, wide landscape composition.”

Shared remaining direction: “Use case: illustration-story. Asset for Beyond the Alibi campus mystery game. Warm vintage detective editorial gouache illustration with fine pencil texture, deep olive, russet and amber, paper grain, elegant realistic restrained brushwork. No people, no text, no logos, no UI, no watermark.”

- Library: empty university library reading room at dusk, shelves, long wooden table, brass lamp, front desk with card scanner and monitor, wall clock, arched windows, quiet amber light; wide landscape.
- Corridor: empty university laboratory corridor and workshop entrance at dusk, wooden and plaster walls, noticeboard with blank papers, security monitor on a desk, steel tool trolley, warm lamps, dark teal shadows; wide landscape.
- Tag: one torn cream inventory label with orange striped security seal attached to a black rectangular hard-shell transport case, close-up still life on a wooden lab bench, blank label with no letters or numbers, precise pencil and gouache detail; square.

Image details are atmospheric, not a substitute for exact case facts. The application renders record transcripts as real text so labels, times, names and clue IDs remain precise and accessible.
