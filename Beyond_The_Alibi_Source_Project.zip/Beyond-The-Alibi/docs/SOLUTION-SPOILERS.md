# Faculty / demonstration walkthrough — SPOILERS

**Culprit: Aarav Mehta (S01).** The game is fictional and its records are authored for this exercise.

## Exact required board connections

| Evidence | Person | Relationship |
|---|---|---|
| E01 — Lab entry record | Aarav Mehta | Places at location |
| E06 — Corridor camera review | Aarav Mehta | Places at location |
| E08 — Library arrival log | Aarav Mehta | Contradicts alibi |

Choose Aarav on the accusation screen and submit. The three required links establish lab presence, removal of the identified P-17 case, and a false library alibi. Additional links can be present. Notes are not graded.

## Complete sequence

1. Open the case briefing and explain the 17:35–17:55 window.
2. Explore the lab. Collect E01, E02 and E03. E02 identifies the sealed case; E03 establishes that no removal was authorised.
3. Explore the library. Collect E04, E08 and E09. E04 independently supports Meera. E08 contradicts Aarav. E09 suggests motive but does not prove removal.
4. Explore the corridor/workshop. Collect E05, E06 and E07. E05 supports Kabir. E06 identifies Aarav carrying the matching P-17 case. E07 corroborates his return near 17:40.
5. Review all character accounts and create the three links above.
6. Optionally demonstrate a wrong relationship or wrong suspect and the unsupported feedback; correct the link using Edit.
7. Save a timeline note. Stop/restart the Java application, then refresh the browser to demonstrate restoration.
8. Select Aarav and submit the supported accusation. Show the resolution.
9. Use New investigation only after confirming that you want to clear the saved case.

## Timeline

- 17:25–18:10: Meera continuously recorded in the library.
- 17:35: Isha verifies P-17 on the lab bench.
- 17:35–18:05: Kabir continuously recorded in the workshop.
- Approximately 17:40: Isha sees Aarav returning toward the lab.
- 17:42: Aarav enters the lab; camera cross-check confirms identity.
- 17:46: Aarav leaves with the black case bearing the distinctive P-17 seal.
- 17:55: Isha discovers the prototype is missing.
- 18:02: Aarav first enters the library, contradicting his claimed 17:30 arrival.

The inventory photograph does not itself identify a culprit. The motive note does not prove guilt. The conclusion follows from the access record, identified removal and contradicted alibi, with corroborating case context.
