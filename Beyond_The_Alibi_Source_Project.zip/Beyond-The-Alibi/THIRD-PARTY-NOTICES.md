# Third-party notices

This application uses Java, Spring Boot / Spring Framework, Jackson, embedded Apache Tomcat, and their transitive dependencies. The executable JAR retains the bundled libraries and their own META-INF license/notice files. Spring, Jackson and Tomcat components use their respective published licenses; consult the embedded notices and upstream repositories for exact terms. Maven resolves the declared dependencies in pom.xml. No Java runtime is redistributed in this package.

Generated game art is documented in docs/ARTWORK.md. The mark.svg favicon and all game UI/code/case prose were created for this project. No external font downloads or stock-image services are required.

Useful official references:
- https://docs.spring.io/spring-boot/3.4/system-requirements.html
- https://spring.io/guides/gs/spring-boot/
- https://docs.oracle.com/en/java/javase/17/
- https://maven.apache.org/guides/getting-started/
- https://github.com/FasterXML/jackson-databind
