# Beyond the Alibi — source package

This package contains the complete source code for the Java web game. It does not include the precompiled `beyond-the-alibi.jar`, because that file bundles Spring Boot and other libraries and makes the ZIP exceed a 25 MB upload limit.

## Build and play

Requirements: JDK 17 or newer and Apache Maven 3.6.3 or newer. Internet access is needed during the first build so Maven can download the project dependencies.

1. Extract this ZIP.
2. Open a terminal in the extracted `Beyond-The-Alibi` folder (the folder containing `pom.xml`).
3. Build and run:

   ```sh
   mvn clean package
   java -jar target/beyond-the-alibi.jar
   ```

4. When the terminal reports that the application has started, open http://localhost:8080 . Keep the terminal open while playing; press Ctrl+C to stop.

On Windows, these commands work in Command Prompt or PowerShell if Maven and Java are on PATH. In IntelliJ IDEA, import the folder as an existing Maven project, run the Maven `package` goal, then run `target/beyond-the-alibi.jar`.

To use port 8081 instead: `java -jar target/beyond-the-alibi.jar --server.port=8081`, then visit http://localhost:8081 .

The built JAR contains the web application and its Java dependencies. The player save is stored locally under the user's home folder. Story content is in `src/main/resources/case/`; the answer key is server-side. Full code, design, demo spoilers and tests are included in the folders.

## Test

Run `mvn test`. The optional real-server check requires Python 3 and a built JAR: `python scripts/smoke_test.py`.

See `docs/ARCHITECTURE.md` for the code structure and `docs/SOLUTION-SPOILERS.md` for the faculty/demo walkthrough (spoilers).
