"""Optional real-JAR HTTP smoke test. Python 3, Java 17+, no Python dependencies.
Run from the project root: python scripts/smoke_test.py
Uses a temporary save directory and an ephemeral localhost port.
"""
import json, pathlib, re, subprocess, tempfile, time, urllib.request, urllib.error
root=pathlib.Path(__file__).resolve().parents[1]
jar=root/'beyond-the-alibi.jar'
if not jar.exists():jar=root/'target/beyond-the-alibi.jar'
assert jar.exists(), 'Build the JAR first: mvn package'
http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
checks=[]
with tempfile.TemporaryDirectory(prefix='alibi-smoke-') as td:
    temp=pathlib.Path(td)
    def boot(label):
        log=temp/(label+'.log'); handle=log.open('w')
        proc=subprocess.Popen(['java','-jar',str(jar),'--server.port=0','--server.address=127.0.0.1','--game.save-dir='+str(temp/'saves')],stdout=handle,stderr=subprocess.STDOUT)
        for _ in range(150):
            match=re.search(r'Tomcat started on port (\d+)',log.read_text())
            if match:return proc,handle,'http://127.0.0.1:'+match.group(1)
            if proc.poll() is not None:raise AssertionError(log.read_text())
            time.sleep(.1)
        proc.terminate();proc.wait();handle.close();raise AssertionError('Startup timed out')
    def stop(proc,handle):
        proc.terminate()
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:proc.kill();proc.wait()
        handle.close()
    def call(path,method='GET',payload=None,expected=200,header=True):
        headers={'Content-Type':'application/json'}
        if header:headers['X-Game-Request']='1'
        req=urllib.request.Request(base+path,data=json.dumps(payload).encode() if payload is not None else None,method=method,headers=headers)
        try:r=http.open(req,timeout=8)
        except urllib.error.HTTPError as e:r=e
        body=r.read();assert r.status==expected,(path,r.status,body[:300])
        return json.loads(body) if r.headers.get('Content-Type','').startswith('application/json') else body
    p,h,base=boot('first')
    try:
        assert b'Beyond the Alibi' in call('/');checks.append('Real JAR serves the game page')
        c=call('/api/case');assert len(c['locations'])==3 and len(c['clues'])==9 and len(c['people'])==4
        assert 'requiredLinks' not in json.dumps(c);call('/case/solution.json',expected=404);checks.append('Public case excludes answer key')
        for image in ['aarav','meera','kabir','isha','lab','library','corridor','tag']:assert len(call('/assets/'+image+'.webp'))>1000
        checks.append('All eight image assets served')
        call('/api/inspect/E01','POST',expected=403,header=False)
        call('/api/inspect/UNKNOWN','POST',expected=400);checks.append('Invalid and unmarked mutations rejected')
        for clue in c['clues']:call('/api/inspect/'+clue['id'],'POST')
        assert len(call('/api/state')['evidence'])==9;checks.append('All nine clues collected through HTTP')
        call('/api/suspect','PUT',{'personId':'S01'})
        assert call('/api/verdict','POST')['result']['status']=='incomplete';checks.append('Correct name alone does not solve')
        for clue,relation in [('E01','PLACES_AT_LOCATION'),('E06','PLACES_AT_LOCATION'),('E08','CONTRADICTS_ALIBI')]:
            call('/api/links','POST',{'evidenceId':clue,'personId':'S01','relation':relation,'note':'Evidence checked'})
        call('/api/notes','PUT',{'text':'Timeline checked. Unicode: café ✓'})
        call('/api/suspect','PUT',{'personId':'S02'})
        assert call('/api/verdict','POST')['result']['status']=='unsupported';checks.append('Wrong suspect rejected')
        call('/api/suspect','PUT',{'personId':'S01'})
        assert call('/api/verdict','POST')['result']['status']=='solved';checks.append('Supported solution accepted')
    finally:stop(p,h)
    p,h,base=boot('restart')
    try:
        s=call('/api/state');assert s['progress']['solved'] and len(s['evidence'])==9 and 'café ✓' in s['progress']['notes']
        checks.append('Solved state, evidence, links and notes survive actual server restart')
        s=call('/api/reset','POST');assert not s['progress']['solved'] and not s['progress']['discoveredIds']
        checks.append('Replay resets saved progress')
    finally:stop(p,h)
print(json.dumps({'passed':len(checks),'checks':checks},indent=2))
