package com.beyondthealibi.model;
public interface VerdictEvaluator { VerdictResult evaluate(Investigation investigation); }
