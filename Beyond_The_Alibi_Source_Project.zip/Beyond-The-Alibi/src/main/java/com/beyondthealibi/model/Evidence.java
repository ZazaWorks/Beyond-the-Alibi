package com.beyondthealibi.model;
public abstract class Evidence {
 private final String id,title,locationId,source,visual,transcript;
 private final int x,y;
 protected Evidence(String id,String title,String locationId,String source,String visual,String transcript,int x,int y){this.id=id;this.title=title;this.locationId=locationId;this.source=source;this.visual=visual;this.transcript=transcript;this.x=x;this.y=y;}
 public String getId(){return id;} public String getTitle(){return title;} public String getLocationId(){return locationId;} public String getSource(){return source;} public String getVisual(){return visual;} public String getTranscript(){return transcript;} public int getX(){return x;} public int getY(){return y;}
 public abstract String getSummary(); public abstract String getKind();
}
