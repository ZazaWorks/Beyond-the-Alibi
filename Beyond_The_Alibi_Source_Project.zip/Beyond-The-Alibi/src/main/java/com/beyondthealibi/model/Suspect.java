package com.beyondthealibi.model;
public final class Suspect extends Person {
 private final String alibi;
 public Suspect(String id,String name,String role,String portrait,String account){super(id,name,role,portrait);this.alibi=account;}
 @Override public String getAccount(){return alibi;}
}
