package com.beyondthealibi.model;
public record Location(String id,String name,String description,String image,String atmosphere) {}
