package com.beyondthealibi.model;
public final class PhysicalEvidence extends Evidence {
 private final String description; 
 public PhysicalEvidence(String id,String title,String location,String source,String visual,String transcript,int x,int y,String summary){super(id,title,location,source,visual,transcript,x,y);this.description=summary;}
 @Override public String getSummary(){return description;} @Override public String getKind(){return "physical";} 
}
