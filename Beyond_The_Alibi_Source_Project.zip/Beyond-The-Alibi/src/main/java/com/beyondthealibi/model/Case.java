package com.beyondthealibi.model;
import java.util.*;
public final class Case {
 private final String id,title,briefing;
 private final List<Location> locations; private final List<Person> people; private final Map<String,Evidence> evidence;
 public Case(String id,String title,String briefing,List<Location> locations,List<Person> people,List<Evidence> evidence){this.id=id;this.title=title;this.briefing=briefing;this.locations=List.copyOf(locations);this.people=List.copyOf(people);var map=new LinkedHashMap<String,Evidence>();for(var e:evidence){if(map.put(e.getId(),e)!=null)throw new IllegalArgumentException("Duplicate evidence ID");}this.evidence=Collections.unmodifiableMap(map);}
 public String getId(){return id;}public String getTitle(){return title;}public String getBriefing(){return briefing;}
 public List<Location> getLocations(){return locations;}public List<Person> getPeople(){return people;}public List<Evidence> getEvidenceItems(){return List.copyOf(evidence.values());}
 public Evidence getEvidence(String id){var e=evidence.get(id);if(e==null)throw new IllegalArgumentException("Unknown evidence.");return e;}
 public Person getPerson(String id){return people.stream().filter(p->p.getId().equals(id)).findFirst().orElseThrow(()->new IllegalArgumentException("Unknown person."));}
}
