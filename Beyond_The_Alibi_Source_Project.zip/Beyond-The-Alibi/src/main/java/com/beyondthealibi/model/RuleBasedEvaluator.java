package com.beyondthealibi.model;
import java.util.*;
public final class RuleBasedEvaluator implements VerdictEvaluator {
 private final String suspectId,explanation; private final Set<String> required;
 public RuleBasedEvaluator(String suspectId,Set<String> required,String explanation){this.suspectId=suspectId;this.required=Set.copyOf(required);this.explanation=explanation;}
 public VerdictResult evaluate(Investigation i){
  if(i.getSelectedSuspect().isBlank())throw new IllegalArgumentException("Choose a suspect before submitting.");
  if(i.getLinks().size()<required.size())return new VerdictResult("incomplete","Your accusation needs at least three evidence links. Establish opportunity, removal of the prototype, and the false alibi.","");
  var keys=new HashSet<String>();for(var l:i.getLinks())keys.add(l.key());
  if(suspectId.equals(i.getSelectedSuspect()) && keys.containsAll(required))return new VerdictResult("solved","Case closed. Your conclusion is supported by the evidence.",explanation);
  return new VerdictResult("unsupported","The submitted theory is not fully supported. Recheck the suspect, the lab entry, the corridor record, and the library arrival time. Match each clue to the relationship it actually proves.","");
 }
}
