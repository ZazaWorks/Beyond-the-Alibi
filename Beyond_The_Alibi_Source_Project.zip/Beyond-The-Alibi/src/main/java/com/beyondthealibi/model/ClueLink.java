package com.beyondthealibi.model;
public record ClueLink(String evidenceId,String personId,RelationType relation,String note) {
 public String key(){return evidenceId+":"+personId+":"+relation.name();}
}
