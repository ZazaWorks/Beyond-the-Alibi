package com.beyondthealibi.model;
public final class Witness extends Person {
 private final String statement;
 public Witness(String id,String name,String role,String portrait,String account){super(id,name,role,portrait);this.statement=account;}
 @Override public String getAccount(){return statement;}
}
