package com.beyondthealibi.model;
public abstract class Person {
 private final String id, name, role, portrait;
 protected Person(String id,String name,String role,String portrait) { this.id=id;this.name=name;this.role=role;this.portrait=portrait; }
 public String getId(){return id;} public String getName(){return name;} public String getRole(){return role;} public String getPortrait(){return portrait;}
 public abstract String getAccount();
 public String getKind(){return this instanceof Suspect ? "suspect" : "witness";}
}
