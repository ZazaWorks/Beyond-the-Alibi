package com.beyondthealibi.model;
public enum RelationType { SUPPORTS_ALIBI, CONTRADICTS_ALIBI, PLACES_AT_LOCATION }
