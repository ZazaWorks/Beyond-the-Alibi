package com.beyondthealibi.model;
import java.util.*;
public record Progress(int version,String caseId,Set<String> discoveredIds,List<ClueLink> links,String notes,String selectedSuspect,int attempts,int hintsUsed,boolean solved,String updatedAt) {}
