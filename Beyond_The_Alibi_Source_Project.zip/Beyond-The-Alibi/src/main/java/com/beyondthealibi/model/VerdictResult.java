package com.beyondthealibi.model;
public record VerdictResult(String status,String message,String explanation) {}
