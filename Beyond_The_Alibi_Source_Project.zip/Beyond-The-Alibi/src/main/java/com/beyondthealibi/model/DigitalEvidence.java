package com.beyondthealibi.model;
public final class DigitalEvidence extends Evidence {
 private final String recordText; private final java.time.LocalDateTime timestamp;
 public DigitalEvidence(String id,String title,String location,String source,String visual,String transcript,int x,int y,String summary,java.time.LocalDateTime timestamp){super(id,title,location,source,visual,transcript,x,y);this.recordText=summary;this.timestamp=timestamp;}
 @Override public String getSummary(){return recordText;} @Override public String getKind(){return "digital";} public java.time.LocalDateTime getTimestamp(){return timestamp;}
}
