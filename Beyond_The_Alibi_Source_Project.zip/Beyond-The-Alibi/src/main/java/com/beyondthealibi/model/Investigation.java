package com.beyondthealibi.model;
import java.util.*;
public final class Investigation {
 private final Case caseFile; private final VerdictEvaluator evaluator;
 private final Set<String> discoveredIds=new LinkedHashSet<>(); private final List<ClueLink> links=new ArrayList<>();
 private String notes="",selectedSuspect="",updatedAt="";private int attempts,hintsUsed;private boolean solved;
 public Investigation(Case c,VerdictEvaluator evaluator){this.caseFile=c;this.evaluator=evaluator;}
 public Set<String> getDiscoveredIds(){return Collections.unmodifiableSet(discoveredIds);}public List<ClueLink> getLinks(){return List.copyOf(links);}public String getSelectedSuspect(){return selectedSuspect;}
 public void discover(String id){caseFile.getEvidence(id);discoveredIds.add(id);}
 public void addLink(ClueLink link){validateLink(link);if(links.stream().anyMatch(l->l.key().equals(link.key())))throw new IllegalArgumentException("That connection is already on your board.");if(links.size()>=100)throw new IllegalArgumentException("Remove a connection before adding more.");links.add(link);}
 private void validateLink(ClueLink l){if(l==null||l.relation()==null)throw new IllegalArgumentException("Choose a relationship.");if(!discoveredIds.contains(l.evidenceId()))throw new IllegalArgumentException("Inspect this evidence before linking it.");caseFile.getPerson(l.personId());if(l.note()==null||l.note().length()>500)throw new IllegalArgumentException("A link note can contain up to 500 characters.");}
 public void editLink(String key,ClueLink next){validateLink(next);int i=index(key);if(links.stream().anyMatch(l->!l.key().equals(key)&&l.key().equals(next.key())))throw new IllegalArgumentException("That connection already exists.");links.set(i,next);}
 private int index(String key){for(int i=0;i<links.size();i++)if(links.get(i).key().equals(key))return i;throw new IllegalArgumentException("Connection not found.");}
 public void removeLink(String key){links.remove(index(key));}
 public void setNotes(String value){if(value==null||value.length()>10000)throw new IllegalArgumentException("Notes must be at most 10,000 characters.");notes=value;}
 public void selectSuspect(String id){if(id==null)throw new IllegalArgumentException("Choose a suspect.");if(!id.isBlank()&&!(caseFile.getPerson(id) instanceof Suspect))throw new IllegalArgumentException("A witness cannot be accused.");selectedSuspect=id;}
 public VerdictResult submitVerdict(){if(solved)return evaluator.evaluate(this);var result=evaluator.evaluate(this);attempts++;solved=result.status().equals("solved");return result;}
 public int hint(){hintsUsed=Math.min(hintsUsed+1,3);return hintsUsed;}
 public Progress snapshot(){return new Progress(1,caseFile.getId(),Set.copyOf(discoveredIds),List.copyOf(links),notes,selectedSuspect,attempts,hintsUsed,solved,updatedAt);}
 public void touch(){updatedAt=java.time.Instant.now().toString();}
 public static Investigation restore(Case c,VerdictEvaluator e,Progress p){if(p==null||p.version()!=1||!c.getId().equals(p.caseId()))throw new IllegalArgumentException("Unsupported save format or case.");var i=new Investigation(c,e);for(var id:p.discoveredIds())i.discover(id);for(var l:p.links())i.addLink(l);i.setNotes(p.notes());i.selectSuspect(p.selectedSuspect());if(p.attempts()<0||p.hintsUsed()<0||p.hintsUsed()>3)throw new IllegalArgumentException("Invalid saved counters.");i.attempts=p.attempts();i.hintsUsed=p.hintsUsed();i.updatedAt=p.updatedAt();if(p.solved()){if(!e.evaluate(i).status().equals("solved"))throw new IllegalArgumentException("Invalid solved state.");i.solved=true;}return i;}
}
