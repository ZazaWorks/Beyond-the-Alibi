package com.beyondthealibi.model;
public final class Testimony extends Evidence {
 private final String statement; private final Person speaker;
 public Testimony(String id,String title,String location,String source,String visual,String transcript,int x,int y,String summary,Person speaker){super(id,title,location,source,visual,transcript,x,y);this.statement=summary;this.speaker=speaker;}
 @Override public String getSummary(){return statement;} @Override public String getKind(){return "testimony";} public String getSpeakerId(){return speaker.getId();}
}
