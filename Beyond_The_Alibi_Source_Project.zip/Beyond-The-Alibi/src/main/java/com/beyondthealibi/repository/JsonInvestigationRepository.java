package com.beyondthealibi.repository;
import com.beyondthealibi.model.Progress;import com.fasterxml.jackson.databind.ObjectMapper;import java.io.*;import java.nio.file.*;import java.util.*;
public final class JsonInvestigationRepository implements Repository<Progress> {
 private final Path path; private final ObjectMapper mapper;
 public JsonInvestigationRepository(Path directory,ObjectMapper mapper)throws IOException{Files.createDirectories(directory);this.path=directory.resolve("progress.json");this.mapper=mapper;}
 public Optional<Progress> load()throws IOException {if(!Files.exists(path))return Optional.empty();if(Files.size(path)>200000)throw new IOException("Save exceeds supported size.");return Optional.of(mapper.readValue(path.toFile(),Progress.class));}
 public void save(Progress value)throws IOException {Path tmp=Files.createTempFile(path.getParent(),"progress-",".tmp");try{mapper.writerWithDefaultPrettyPrinter().writeValue(tmp.toFile(),value);try{Files.move(tmp,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING);}}finally{Files.deleteIfExists(tmp);}}
 public void quarantine()throws IOException{if(Files.exists(path))Files.move(path,path.resolveSibling("progress-corrupt-"+System.currentTimeMillis()+".json"));}
}
