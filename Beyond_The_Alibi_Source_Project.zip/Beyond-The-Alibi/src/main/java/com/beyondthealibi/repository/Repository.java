package com.beyondthealibi.repository;
import java.io.IOException;import java.util.Optional;
public interface Repository<T> { Optional<T> load() throws IOException;void save(T value) throws IOException; }
