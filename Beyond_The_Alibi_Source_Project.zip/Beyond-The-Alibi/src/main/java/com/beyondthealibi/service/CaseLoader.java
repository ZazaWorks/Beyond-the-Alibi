package com.beyondthealibi.service;
import com.beyondthealibi.model.*;import com.beyondthealibi.model.Case;import com.fasterxml.jackson.databind.*;import org.springframework.stereotype.Component;import java.util.*;
@Component
public class CaseLoader {
 private final Case caseFile;private final VerdictEvaluator evaluator;
 public CaseLoader(ObjectMapper mapper)throws Exception{
  JsonNode n;try(var in=getClass().getResourceAsStream("/case/case.json")){n=mapper.readTree(in);}
  var people=new ArrayList<Person>();for(var p:n.get("people")){String id=p.get("id").asText(),name=p.get("name").asText(),role=p.get("role").asText(),image=p.get("portrait").asText(),account=p.get("account").asText();people.add(p.get("kind").asText().equals("suspect")?new Suspect(id,name,role,image,account):new Witness(id,name,role,image,account));}
  var locations=new ArrayList<Location>();for(var l:n.get("locations"))locations.add(mapper.treeToValue(l,Location.class));
  var evidence=new ArrayList<Evidence>();for(var v:n.get("evidence")){
   String id=v.get("id").asText(),title=v.get("title").asText(),loc=v.get("locationId").asText(),source=v.get("source").asText(),visual=v.get("visual").asText(),transcript=v.get("transcript").asText(),summary=v.get("summary").asText();int x=v.get("x").asInt(),y=v.get("y").asInt();
   Evidence e=switch(v.get("kind").asText()){case "physical"->new PhysicalEvidence(id,title,loc,source,visual,transcript,x,y,summary);case "digital"->new DigitalEvidence(id,title,loc,source,visual,transcript,x,y,summary,java.time.LocalDateTime.parse(v.get("timestamp").asText()));case "testimony"->new Testimony(id,title,loc,source,visual,transcript,x,y,summary,people.stream().filter(p->p.getId().equals(v.get("speakerId").asText())).findFirst().orElseThrow());default->throw new IllegalArgumentException("Unknown clue kind");};evidence.add(e);
  }
  caseFile=new Case(n.get("id").asText(),n.get("title").asText(),n.get("briefing").asText(),locations,people,evidence);
  JsonNode s;try(var in=getClass().getResourceAsStream("/case/solution.json")){s=mapper.readTree(in);}var keys=new HashSet<String>();for(var k:s.get("requiredLinks"))keys.add(k.asText());evaluator=new RuleBasedEvaluator(s.get("suspectId").asText(),keys,s.get("explanation").asText());
 }
 public Case caseFile(){return caseFile;}public VerdictEvaluator evaluator(){return evaluator;}
}
