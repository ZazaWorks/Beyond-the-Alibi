package com.beyondthealibi.service;
import com.beyondthealibi.model.*;import com.beyondthealibi.repository.*;import com.fasterxml.jackson.databind.ObjectMapper;import org.springframework.beans.factory.annotation.Value;import org.springframework.stereotype.Service;import java.nio.file.*;import java.io.*;import java.util.*;import java.util.function.Function;
@Service
public class InvestigationService {
 private final CaseLoader loader;private final Repository<Progress> repository;private Investigation current;private String warning="";
 public InvestigationService(CaseLoader loader,ObjectMapper mapper,@Value("${game.save-dir}")String directory)throws IOException{
  this.loader=loader;var repo=new JsonInvestigationRepository(Path.of(directory),mapper);repository=repo;current=new Investigation(loader.caseFile(),loader.evaluator());
  try{var saved=repo.load();if(saved.isPresent())current=Investigation.restore(loader.caseFile(),loader.evaluator(),saved.get());}catch(Exception e){repo.quarantine();warning="An unreadable save was preserved as a backup. A new investigation has been opened.";}
 }
 private <T>T mutate(Function<Investigation,T> action)throws IOException{var next=Investigation.restore(loader.caseFile(),loader.evaluator(),current.snapshot());if(next.snapshot().solved())throw new IllegalArgumentException("This case is closed. Start a new investigation to change it.");T result=action.apply(next);next.touch();repository.save(next.snapshot());current=next;return result;}
 public synchronized Map<String,Object> state(){var s=current.snapshot();var m=new LinkedHashMap<String,Object>();m.put("progress",s);m.put("evidence",loader.caseFile().getEvidenceItems().stream().filter(e->s.discoveredIds().contains(e.getId())).toList());m.put("warning",warning);if(s.solved())m.put("result",loader.evaluator().evaluate(current));return m;}
 public synchronized Object inspect(String id)throws IOException{mutate(i->{i.discover(id);return null;});return state();}
 public synchronized Object add(ClueLink link)throws IOException{mutate(i->{i.addLink(link);return null;});return state();}
 public synchronized Object edit(String key,ClueLink link)throws IOException{mutate(i->{i.editLink(key,link);return null;});return state();}
 public synchronized Object remove(String key)throws IOException{mutate(i->{i.removeLink(key);return null;});return state();}
 public synchronized Object notes(String notes)throws IOException{mutate(i->{i.setNotes(notes);return null;});return state();}
 public synchronized Object select(String id)throws IOException{mutate(i->{i.selectSuspect(id);return null;});return state();}
 public synchronized Object verdict()throws IOException{if(current.snapshot().solved())return Map.of("result",loader.evaluator().evaluate(current),"state",state());var result=mutate(Investigation::submitVerdict);return Map.of("result",result,"state",state());}
 public synchronized Object hint()throws IOException{int level=mutate(Investigation::hint);String text=switch(level){case 1->"Visit all three locations. Separate a claim from an independent record, and compare their times.";case 2->"A lab entry establishes presence. A corridor record establishes who carried the prototype. A later library arrival challenges an earlier alibi.";default->"On the board: link E01 and E06 to Aarav with ‘Places at location’; link E08 to Aarav with ‘Contradicts alibi’. Then select Aarav in your accusation.";};return Map.of("hint",text,"state",state());}
 public synchronized Object reset()throws IOException{var next=new Investigation(loader.caseFile(),loader.evaluator());next.touch();repository.save(next.snapshot());current=next;warning="";return state();}
 public synchronized Object caseView(){var c=loader.caseFile();return Map.of("id",c.getId(),"title",c.getTitle(),"briefing",c.getBriefing(),"locations",c.getLocations(),"people",c.getPeople(),"clues",c.getEvidenceItems().stream().map(e->Map.of("id",e.getId(),"title",e.getTitle(),"locationId",e.getLocationId(),"x",e.getX(),"y",e.getY(),"kind",e.getKind())).toList());}
}
