package com.beyondthealibi.web;
import com.beyondthealibi.service.InvestigationService;import com.beyondthealibi.model.ClueLink;import org.springframework.web.bind.annotation.*;import java.io.IOException;
@RestController @RequestMapping("/api")
public class GameController {
 private final InvestigationService game;public GameController(InvestigationService game){this.game=game;}
 record TextInput(String text){} record PersonInput(String personId){}
 @GetMapping("/case")public Object caseFile(){return game.caseView();}
 @GetMapping("/state")public Object state(){return game.state();}
 @PostMapping("/inspect/{id}")public Object inspect(@PathVariable String id)throws IOException{return game.inspect(id);}
 @PostMapping("/links")public Object link(@RequestBody ClueLink link)throws IOException{return game.add(link);}
 @PutMapping("/links/{key}")public Object edit(@PathVariable String key,@RequestBody ClueLink link)throws IOException{return game.edit(key,link);}
 @DeleteMapping("/links/{key}")public Object delete(@PathVariable String key)throws IOException{return game.remove(key);}
 @PutMapping("/notes")public Object notes(@RequestBody TextInput value)throws IOException{return game.notes(value.text());}
 @PutMapping("/suspect")public Object suspect(@RequestBody PersonInput value)throws IOException{return game.select(value.personId());}
 @PostMapping("/verdict")public Object verdict()throws IOException{return game.verdict();}
 @PostMapping("/hint")public Object hint()throws IOException{return game.hint();}
 @PostMapping("/reset")public Object reset()throws IOException{return game.reset();}
}
