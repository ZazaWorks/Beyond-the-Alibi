package com.beyondthealibi.web;
import org.springframework.web.bind.annotation.*;import org.springframework.http.*;import org.springframework.http.converter.HttpMessageNotReadableException;import java.util.Map;import java.io.IOException;
@RestControllerAdvice
public class ApiErrors {
 @ExceptionHandler({IllegalArgumentException.class,HttpMessageNotReadableException.class})public ResponseEntity<?> bad(Exception e){String message=e instanceof HttpMessageNotReadableException?"The request contains invalid or missing values.":e.getMessage();return ResponseEntity.badRequest().body(Map.of("message",message==null?"Invalid request.":message));}
 @ExceptionHandler(IOException.class)public ResponseEntity<?> storage(IOException e){return ResponseEntity.status(503).body(Map.of("message","Progress could not be saved. Your previous save is safe. Check disk space and folder permissions, then try again."));}
}
