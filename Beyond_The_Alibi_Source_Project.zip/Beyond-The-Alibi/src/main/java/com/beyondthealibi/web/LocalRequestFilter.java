package com.beyondthealibi.web;
import jakarta.servlet.*;import jakarta.servlet.http.*;import org.springframework.stereotype.Component;import org.springframework.web.filter.OncePerRequestFilter;import java.io.IOException;
@Component
public class LocalRequestFilter extends OncePerRequestFilter {
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","same-origin");
  res.setHeader("Content-Security-Policy","default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
  if(req.getRequestURI().startsWith("/api/")){res.setHeader("Cache-Control","no-store");if(!req.getMethod().equals("GET")&&!req.getMethod().equals("HEAD")&&!"1".equals(req.getHeader("X-Game-Request"))){res.setStatus(403);res.setContentType("application/json");res.getWriter().write("{\"message\":\"Use the game interface to submit actions.\"}");return;}}
  chain.doFilter(req,res);
 }
}
