package com.beyondthealibi;
import org.junit.jupiter.api.*;import org.springframework.beans.factory.annotation.Autowired;import org.springframework.boot.test.context.SpringBootTest;import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;import org.springframework.test.web.servlet.MockMvc;import org.springframework.test.context.DynamicPropertyRegistry;import org.springframework.test.context.DynamicPropertySource;import java.nio.file.*;import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;import static org.hamcrest.Matchers.*;
@SpringBootTest @AutoConfigureMockMvc
class ApiTest {
 @Autowired MockMvc mvc;static final Path temp;static{try{temp=Files.createTempDirectory("alibi-api-test-");}catch(Exception e){throw new RuntimeException(e);}}
 @DynamicPropertySource static void props(DynamicPropertyRegistry r){r.add("game.save-dir",()->temp.toString());}
 @BeforeEach void reset()throws Exception{mvc.perform(post("/api/reset").header("X-Game-Request","1")).andExpect(status().isOk());}
 @Test void clientCannotReadSolutionOrUndiscoveredDetails()throws Exception{mvc.perform(get("/api/case")).andExpect(status().isOk()).andExpect(content().string(not(containsString("requiredLinks")))).andExpect(content().string(not(containsString("18:02:11"))));mvc.perform(get("/case/solution.json")).andExpect(status().isNotFound());mvc.perform(get("/api/state")).andExpect(jsonPath("$.evidence",hasSize(0)));}
 @Test void mutationsRequireGameHeaderAndValidInput()throws Exception{mvc.perform(post("/api/inspect/E01")).andExpect(status().isForbidden());mvc.perform(post("/api/inspect/missing").header("X-Game-Request","1")).andExpect(status().isBadRequest());mvc.perform(post("/api/links").header("X-Game-Request","1").contentType("application/json").content("{\"relation\":\"INVALID\"}")).andExpect(status().isBadRequest());}
 @Test void completeApiJourney()throws Exception{
  for(String e:new String[]{"E01","E06","E08"})mvc.perform(post("/api/inspect/"+e).header("X-Game-Request","1")).andExpect(status().isOk());
  for(String e:new String[]{"E01","E06","E08"})mvc.perform(post("/api/links").header("X-Game-Request","1").contentType("application/json").content("{\"evidenceId\":\""+e+"\",\"personId\":\"S01\",\"relation\":\""+(e.equals("E08")?"CONTRADICTS_ALIBI":"PLACES_AT_LOCATION")+"\",\"note\":\"checked\"}")).andExpect(status().isOk());
  mvc.perform(put("/api/suspect").header("X-Game-Request","1").contentType("application/json").content("{\"personId\":\"S01\"}")).andExpect(status().isOk());
  mvc.perform(post("/api/verdict").header("X-Game-Request","1")).andExpect(status().isOk()).andExpect(jsonPath("$.result.status").value("solved"));mvc.perform(get("/api/state")).andExpect(jsonPath("$.progress.solved").value(true));
  mvc.perform(post("/api/inspect/E02").header("X-Game-Request","1")).andExpect(status().isBadRequest());
 }
 @Test void webAssetsAndSecurityHeadersExist()throws Exception{mvc.perform(get("/")).andExpect(status().isOk()).andExpect(header().exists("Content-Security-Policy"));mvc.perform(get("/assets/aarav.webp")).andExpect(status().isOk());}
}
